using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerCharacter : MonoBehaviour
{
    #region DataStructures
    public enum PhysicState
    {
        Ground,
        Air
    }

    [Serializable]
    private struct MouvementValue
    {
        public float MaxSpeed;
        public float Acceleration;
        public float MaxAcceleration;
        [Tooltip("Range [-1, 1]")] public AnimationCurve AccelerationRemapFromVelocityDot;
    }
    [Serializable]
    private struct GravityValue
    {
        public float MaxForce;
        public float Acceleration;
        public float MaxAcceleration;
        public float CoyoteTime;
        [Tooltip("Range [0, 1]")]
        public AnimationCurve GravityRemapFromCoyoteTime;
    }
    [Serializable]
    private struct JumpValue
    {
        public float ImpulseForce;
        public float Deceleration;
        public float MaxDecceleration;
        [Tooltip("Range [0, 1]")]
        public AnimationCurve DecelerationFromAirTime;
        public float Height;
        public float BufferTime;
    }
    #endregion

    [Header("Gamplay")]
    [SerializeField] private MouvementValue _groundPhysic = new MouvementValue();
    [SerializeField] private MouvementValue _airPhysic = new MouvementValue();
    [SerializeField] private GravityValue _gravityParam = new GravityValue();
    [SerializeField] private JumpValue _jumpParam = new JumpValue();
    [SerializeField] private ContactFilter2D _groundContactFilter = new ContactFilter2D();

    [Header("Setup")]
    [SerializeField] private Transform _mesh = null;
    [SerializeField] private float _meshRotationSpeed = 300.0f;

    //component
    private Rigidbody2D _rigidBody = null;

    //Force
    private Vector2 _forceToAdd = Vector2.zero;

    //horizontal movement
    private float _currentHorizontalSpeed = 0.0f;
    private float _mouvementInput = 0.0f;
    private MouvementValue _horizontalPhysic = new MouvementValue();

    //Gravity
    private float _currentGravity = 0.0f;

    //Ground
    private bool _isGrounded = true;

    //air
    private float _airTime = 0.0f;
    private bool _isCoyotTime = false;

    //Jump
    private float _currentJumpForce = 0.0f;
    private bool _isJumping = false;
    private float _JumpTime = 0.0f;
    private float _startJumpTime = 0.0f;
    private bool _Bufferjump = false;

    //Event appeler quand on touche ou quitte le sol
    public event Action<PhysicState> OnPhysicStateChanged;
    public event Action OnLeavingGround;


    private void Awake()
    {
        _rigidBody = GetComponent<Rigidbody2D>();
        _horizontalPhysic = _groundPhysic;

        OnPhysicStateChanged += ChangePhysic;
        OnPhysicStateChanged += ResetGravity;
        OnPhysicStateChanged += CancelJump;
        OnPhysicStateChanged += TryJumpFromBuffer;
        CalculateJumpTime();
    }

#if UNITY_EDITOR
    public void OnValidate()
    {
        CalculateJumpTime();
    }
#endif

    public void CalculateJumpTime()
    {
        _JumpTime = _jumpParam.Height / _jumpParam.ImpulseForce;
    }

    private void Update()
    {
        RotateMesh();

    }

    private void FixedUpdate()
    {
        // on reset la force a ajouter cette boucle de fixe update
        _forceToAdd = Vector2.zero;

        //Fonction qui d�tecte si on touche le sol ou non
        //Et appelle les events associ�s
        GroundDetection();
        ManageAirTime();
        ManageCoyotetime();

        //on effectue tous des calculs physique
        Movement();
        Gravity();
        JumpForce();


        //on ajoute la force au rigidBody
        _rigidBody.velocity += _forceToAdd;
    }

    private void GroundDetection()
    {
        //On utnilise le filtre qui contien l'inclinaison du sol pour savoir si le giridbody touche le sol ou non
        bool isTouchingGround = _rigidBody.IsTouching(_groundContactFilter);

        //Si le rigidbody touche le sol mais on a en m�moire qu'il ne le touche pas, on est sur la frame ou il touche le sol
        if (isTouchingGround && !_isGrounded)
        {
            _isGrounded = true;
            OnPhysicStateChanged.Invoke(PhysicState.Ground);
        }
        else if (!isTouchingGround && _isGrounded)
        {
            _isGrounded = false;
            if (!_isJumping)
                _isCoyotTime = true;
            OnPhysicStateChanged.Invoke(PhysicState.Air);
        }
    }

    private void ManageAirTime()
    {
        if (!_isGrounded)
            _airTime += Time.fixedDeltaTime;
    }

    private void ManageCoyotetime()
    {
        if (_airTime > _gravityParam.CoyoteTime)
            _isCoyotTime = false;
    }

    private void ChangePhysic(PhysicState isGround)
    {
        //On change la physique en fonction de si le joueur est au sol ou non
        if (isGround == PhysicState.Ground)
            _horizontalPhysic = _groundPhysic;
        else if (isGround == PhysicState.Air)
            _horizontalPhysic = _airPhysic;
    }

    public void Movement()
    {
        float maxspeed = _horizontalPhysic.MaxSpeed * _mouvementInput;
        float velocityDot = Mathf.Clamp( _rigidBody.velocity.x * maxspeed, -1.0f, 1.0f );
        velocityDot = _horizontalPhysic.AccelerationRemapFromVelocityDot.Evaluate( velocityDot );
        float acceleration = _horizontalPhysic.Acceleration * velocityDot * Time.fixedDeltaTime;


        //on fait avancer notre vitesse actuelle vers la max speed en fonctione de l'acceleration
        _currentHorizontalSpeed = Mathf.MoveTowards(_currentHorizontalSpeed, maxspeed, acceleration);

        //on calcule l'�cart entre la velocit� actuelle du rigidbody et la velocit� cible
        float velocityDelta = _currentHorizontalSpeed - _rigidBody.velocity.x;

        //on clamp le delta de v�locit� avec l'acceleration maximum en n�gatif et en positif pour �viter des bugs dans la physic 
        velocityDelta = Mathf.Clamp(velocityDelta, -_horizontalPhysic.MaxAcceleration, _horizontalPhysic.MaxAcceleration);

        //on ajoute le delta 
        _forceToAdd.x += velocityDelta;
    }

    private void Gravity()
    {
        if (_isGrounded || _isJumping)
            return;

        float coyoteTimeRatio = Mathf.Clamp01(_airTime / _gravityParam.CoyoteTime);
        float coyoteTimeFactor = _isCoyotTime ? _gravityParam.GravityRemapFromCoyoteTime.Evaluate(coyoteTimeRatio) : 1.0f;
        float acceleration = _gravityParam.Acceleration * _gravityParam.GravityRemapFromCoyoteTime.Evaluate(coyoteTimeRatio) * Time.fixedDeltaTime;

        _currentGravity = Mathf.MoveTowards(_currentGravity, _gravityParam.MaxForce, acceleration);

        float velocityDelta = _currentGravity - _rigidBody.velocity.y;
        velocityDelta = Mathf.Clamp(velocityDelta, -_gravityParam.MaxAcceleration, 0.0f);

        _forceToAdd.y += velocityDelta;
    }

    private void ResetGravity(PhysicState physicState)
    {
        if (physicState != PhysicState.Air)
        {
            _currentGravity = 0.0f;
            _rigidBody.velocity = new Vector2(_rigidBody.velocity.x, 0.0f);
            _airTime = 0.0f;
        }
    }

    private void RotateMesh()
    {
        //90 a droit / 270 a gauche
        if (_currentHorizontalSpeed == 0.0f)
            return;

        float targetRotation = _currentHorizontalSpeed > 0.0f ? 90.0f : 270.0f;
        float currentRotation = _mesh.eulerAngles.y;
        float newRotation = Mathf.MoveTowards(currentRotation, targetRotation, _meshRotationSpeed * Time.deltaTime);

        _mesh.rotation = Quaternion.Euler(0.0f, newRotation, 0.0f);
    }

    public void GetMovementInput(float input)
    {
        _mouvementInput = input;
    }

    internal void StartJump()
    {
        if ((!_isGrounded && !_isCoyotTime) || _isJumping)
        {
            _Bufferjump = true;
            Invoke(nameof(StopJumpBuffer), _jumpParam.BufferTime);
            return;
        }

        _currentJumpForce = _jumpParam.ImpulseForce;
        _rigidBody.velocity = new Vector2(_rigidBody.velocity.x, _currentJumpForce);
        _isJumping = true;
        _isCoyotTime = false;
        _startJumpTime = _airTime;
    }

    private void StopJumpBuffer()
    {
        _Bufferjump = false;
    }

    public void JumpForce()
    {
        if (!_isJumping)
            return;

        float jumpTimeRatio = Mathf.Clamp01(_airTime - _startJumpTime / _JumpTime);
        float decelerate = _jumpParam.Deceleration * _jumpParam.DecelerationFromAirTime.Evaluate(jumpTimeRatio) * Time.fixedDeltaTime;

        _currentJumpForce = Mathf.MoveTowards(_currentJumpForce, 0.0f, decelerate);

        float velocityDelta = _currentJumpForce - _rigidBody.velocity.y;
        velocityDelta = Mathf.Clamp(velocityDelta, -_jumpParam.MaxDecceleration, 0.0f);

        _forceToAdd.y += velocityDelta;

        if (jumpTimeRatio >= 1.0f)
        {
            _isJumping = false;
            _currentJumpForce = 0.0f;
        }
    }

    private void CancelJump(PhysicState state)
    {
        if (state == PhysicState.Air)
        {
            _isJumping = false;
            _currentJumpForce = 0.0f;
        }
    }

    private void TryJumpFromBuffer(PhysicState state)
    {
        if (state != PhysicState.Air && _Bufferjump)
        {
            StartJump();
            _Bufferjump = false;
            CancelInvoke(nameof(StopJumpBuffer));
        }
    }

    public void ActionOne()
    {

    }

    public void ActionTwo()
    {

    }

}
